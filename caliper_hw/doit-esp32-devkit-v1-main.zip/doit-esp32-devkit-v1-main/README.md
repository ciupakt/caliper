# DOIT ESP32 Devkit V1
DOIT ESP32 DEVKIT V1

### References
1. ESP32 Datasheet http://espressif.com/sites/default/files/documentation/esp32_datasheet_en.pdf
2. ESP WROOM32 Datasheet https://www.espressif.com/sites/default/files/documentation/esp32-wroom-32e_esp32-wroom-32ue_datasheet_en.pdf?msclkid=5f81279fb06c11eca9bb4ae7c1993a9e
3. wroom32 pinout https://www.mouser.com/datasheet/2/891/esp-wroom-32_datasheet_en-1223836.pdf?msclkid=dcd1681fb06c11ec8f43f950f93576ee
